Save the Kitties!
===============================

### Where to Play
Play the game [here!](http://tonirib.github.io/frontend-nanodegree-arcade-game)

### Main Objective

Get all 5 kitties to their correct colored blocks at the top of the screen.

### How to Play

- Use the arrow keys to move Cat Girl around the board
- Pick up each kitty and move it to the correct colored block
- Watch out for the bug enemies! If you hit one of these, you'll lose a life and both Cat Girl and the kitty will reset
  - You can also lose a life by stepping in the water
- If you put the kitty on a block of the incorrect color, Cat Girl and the kitty will reset
- Refresh the page to reset the game (including when you win or lose)